//Magdalena Maksymiuk
bool Emptiness(int set)
{
    if(set==0)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}
bool Nonempty(int set)
{
    if(set==0)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}